<?php
require_once __DIR__ . '/class-itsec-email-confirmation.php';
$module = new ITSEC_Email_Confirmation();
$module->run();
